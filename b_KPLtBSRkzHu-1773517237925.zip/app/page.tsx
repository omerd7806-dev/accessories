"use client"

import { useState, useCallback } from "react"
import { Header } from "@/components/header"
import { HeroBanner } from "@/components/hero-banner"
import { Categories } from "@/components/categories"
import { ProductGallery } from "@/components/product-gallery"
import { Contact } from "@/components/contact"
import { Footer } from "@/components/footer"
import { WhatsAppFloat } from "@/components/whatsapp-float"

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  const handleCategorySelect = useCallback((category: string | null) => {
    setSelectedCategory(category)
    if (category) {
      setTimeout(() => {
        document.getElementById("products")?.scrollIntoView({ behavior: "smooth" })
      }, 100)
    }
  }, [])

  return (
    <main className="min-h-screen">
      <Header />
      
      <HeroBanner />
      
      <Categories
        selectedCategory={selectedCategory}
        onCategorySelect={handleCategorySelect}
      />
      
      <ProductGallery selectedCategory={selectedCategory} />
      
      <Contact />
      
      <Footer />

      <WhatsAppFloat />
    </main>
  )
}
