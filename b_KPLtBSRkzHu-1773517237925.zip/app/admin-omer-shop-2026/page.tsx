"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { Plus, Pencil, Trash2, Upload, X, Save, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

interface Product {
  id: string
  name: string
  description: string
  image: string
  category: string
}

const defaultProducts: Product[] = [
  {
    id: "1",
    name: "خاتم الماس ذهبي",
    description: "خاتم أنيق من الذهب الخالص مرصع بالألماس الطبيعي",
    image: "/images/ring-1.jpg",
    category: "rings",
  },
  {
    id: "2",
    name: "خاتم فضي كلاسيكي",
    description: "خاتم فضي بتصميم كلاسيكي مع حجر كريم",
    image: "/images/ring-2.jpg",
    category: "rings",
  },
  {
    id: "3",
    name: "قلادة لؤلؤ طبيعي",
    description: "قلادة من الذهب الوردي مع لؤلؤة طبيعية",
    image: "/images/necklace-1.jpg",
    category: "necklaces",
  },
  {
    id: "4",
    name: "قلادة كريستال ذهبية",
    description: "سلسلة ذهبية مع تعليقة كريستال لامعة",
    image: "/images/necklace-2.jpg",
    category: "necklaces",
  },
  {
    id: "5",
    name: "سوار سحر ذهبي",
    description: "سوار ذهبي مع تعليقات متنوعة أنيقة",
    image: "/images/bracelet-1.jpg",
    category: "bracelets",
  },
  {
    id: "6",
    name: "سوار لؤلؤ أنيق",
    description: "سوار من اللؤلؤ الطبيعي بتصميم راقي",
    image: "/images/bracelet-2.jpg",
    category: "bracelets",
  },
  {
    id: "7",
    name: "أقراط لؤلؤ متدلية",
    description: "أقراط متدلية من اللؤلؤ الأبيض الفاخر",
    image: "/images/earrings-1.jpg",
    category: "earrings",
  },
  {
    id: "8",
    name: "حلق ذهبي دائري",
    description: "حلق دائري من الذهب مع كريستالات صغيرة",
    image: "/images/earrings-2.jpg",
    category: "earrings",
  },
]

const categories = [
  { id: "rings", name: "خواتم" },
  { id: "necklaces", name: "قلائد" },
  { id: "bracelets", name: "أساور" },
  { id: "earrings", name: "أقراط" },
]

const ADMIN_PASSWORD = "admin2026"

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState("")
  const [passwordError, setPasswordError] = useState("")
  const [products, setProducts] = useState<Product[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    image: "",
    category: "rings",
  })
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const authStatus = sessionStorage.getItem("admin-auth")
    if (authStatus === "true") {
      setIsAuthenticated(true)
    }
  }, [])

  useEffect(() => {
    if (isAuthenticated) {
      const savedProducts = localStorage.getItem("shop-products")
      if (savedProducts) {
        try {
          const parsed = JSON.parse(savedProducts)
          if (Array.isArray(parsed) && parsed.length > 0) {
            setProducts(parsed)
          } else {
            setProducts(defaultProducts)
            localStorage.setItem("shop-products", JSON.stringify(defaultProducts))
          }
        } catch (e) {
          setProducts(defaultProducts)
          localStorage.setItem("shop-products", JSON.stringify(defaultProducts))
        }
      } else {
        setProducts(defaultProducts)
        localStorage.setItem("shop-products", JSON.stringify(defaultProducts))
      }
    }
  }, [isAuthenticated])

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true)
      sessionStorage.setItem("admin-auth", "true")
      setPasswordError("")
    } else {
      setPasswordError("كلمة المرور غير صحيحة")
    }
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    sessionStorage.removeItem("admin-auth")
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        const base64String = reader.result as string
        setImagePreview(base64String)
        setFormData((prev) => ({ ...prev, image: base64String }))
      }
      reader.readAsDataURL(file)
    }
  }

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      image: "",
      category: "rings",
    })
    setImagePreview(null)
    setEditingProduct(null)
  }

  const openAddDialog = () => {
    resetForm()
    setIsDialogOpen(true)
  }

  const openEditDialog = (product: Product) => {
    setEditingProduct(product)
    setFormData({
      name: product.name,
      description: product.description,
      image: product.image,
      category: product.category,
    })
    setImagePreview(product.image)
    setIsDialogOpen(true)
  }

  const handleSave = () => {
    if (!formData.name || !formData.description || !formData.image) {
      alert("يرجى ملء جميع الحقول")
      return
    }

    let updatedProducts: Product[]

    if (editingProduct) {
      updatedProducts = products.map((p) =>
        p.id === editingProduct.id
          ? { ...p, ...formData }
          : p
      )
    } else {
      const newProduct: Product = {
        id: Date.now().toString(),
        ...formData,
      }
      updatedProducts = [...products, newProduct]
    }

    setProducts(updatedProducts)
    localStorage.setItem("shop-products", JSON.stringify(updatedProducts))
    setIsDialogOpen(false)
    resetForm()
  }

  const handleDelete = (id: string) => {
    if (confirm("هل أنت متأكد من حذف هذا المنتج؟")) {
      const updatedProducts = products.filter((p) => p.id !== id)
      setProducts(updatedProducts)
      localStorage.setItem("shop-products", JSON.stringify(updatedProducts))
    }
  }

  const getCategoryName = (categoryId: string) => {
    return categories.find((c) => c.id === categoryId)?.name || categoryId
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4" dir="rtl">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">لوحة التحكم</CardTitle>
            <p className="text-muted-foreground">أدخل كلمة المرور للوصول</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Input
                  type="password"
                  placeholder="كلمة المرور"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="text-center"
                />
                {passwordError && (
                  <p className="text-destructive text-sm mt-2 text-center">{passwordError}</p>
                )}
              </div>
              <Button type="submit" className="w-full">
                دخول
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl md:text-2xl font-bold text-primary">لوحة التحكم - لمسة أنوثة</h1>
          <Button variant="outline" size="sm" onClick={handleLogout}>
            <LogOut className="w-4 h-4 ml-2" />
            خروج
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-3xl font-bold text-primary">{products.length}</p>
              <p className="text-muted-foreground text-sm">إجمالي المنتجات</p>
            </CardContent>
          </Card>
          {categories.map((cat) => (
            <Card key={cat.id}>
              <CardContent className="p-4 text-center">
                <p className="text-3xl font-bold text-primary">
                  {products.filter((p) => p.category === cat.id).length}
                </p>
                <p className="text-muted-foreground text-sm">{cat.name}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Add Product Button */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">إدارة المنتجات</h2>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={openAddDialog}>
                <Plus className="w-4 h-4 ml-2" />
                إضافة منتج
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
              <DialogHeader>
                <DialogTitle>
                  {editingProduct ? "تعديل المنتج" : "إضافة منتج جديد"}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                {/* Image Upload */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">صورة المنتج</label>
                  <div
                    className="border-2 border-dashed border-border rounded-lg p-4 text-center cursor-pointer hover:border-primary transition-colors"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    {imagePreview ? (
                      <div className="relative aspect-square max-w-[200px] mx-auto">
                        <Image
                          src={imagePreview}
                          alt="Preview"
                          fill
                          className="object-cover rounded-lg"
                        />
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation()
                            setImagePreview(null)
                            setFormData((prev) => ({ ...prev, image: "" }))
                          }}
                          className="absolute -top-2 -right-2 bg-destructive text-white rounded-full p-1"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <div className="py-8">
                        <Upload className="w-10 h-10 mx-auto text-muted-foreground mb-2" />
                        <p className="text-muted-foreground text-sm">
                          اضغط لرفع صورة
                        </p>
                        <p className="text-muted-foreground text-xs mt-1">
                          يدعم JPG, PNG, WEBP
                        </p>
                      </div>
                    )}
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </div>

                {/* Name */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">اسم المنتج</label>
                  <Input
                    value={formData.name}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, name: e.target.value }))
                    }
                    placeholder="أدخل اسم المنتج"
                  />
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">وصف المنتج</label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, description: e.target.value }))
                    }
                    placeholder="أدخل وصف المنتج"
                    rows={3}
                  />
                </div>

                {/* Category */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">التصنيف</label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) =>
                      setFormData((prev) => ({ ...prev, category: value }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="اختر التصنيف" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.id} value={cat.id}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Save Button */}
                <Button onClick={handleSave} className="w-full">
                  <Save className="w-4 h-4 ml-2" />
                  {editingProduct ? "حفظ التعديلات" : "إضافة المنتج"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {products.map((product) => (
            <Card key={product.id} className="overflow-hidden">
              <div className="relative aspect-square">
                <Image
                  src={product.image}
                  alt={product.name}
                  fill
                  className="object-cover"
                />
              </div>
              <CardContent className="p-4">
                <h3 className="font-bold text-foreground mb-1 line-clamp-1">
                  {product.name}
                </h3>
                <p className="text-muted-foreground text-sm mb-2 line-clamp-2">
                  {product.description}
                </p>
                <p className="text-xs text-primary mb-3">
                  {getCategoryName(product.category)}
                </p>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => openEditDialog(product)}
                  >
                    <Pencil className="w-4 h-4 ml-1" />
                    تعديل
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    className="flex-1"
                    onClick={() => handleDelete(product.id)}
                  >
                    <Trash2 className="w-4 h-4 ml-1" />
                    حذف
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {products.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">لا توجد منتجات. اضغط على "إضافة منتج" للبدء.</p>
          </div>
        )}
      </main>
    </div>
  )
}
