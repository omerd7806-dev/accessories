"use client"

import { useState } from "react"
import { MapPin, Phone, Mail, Clock, MessageCircle, Send } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

const contactInfo = [
  {
    icon: MapPin,
    title: "العنوان",
    content: "الرياض، المملكة العربية السعودية",
  },
  {
    icon: Phone,
    title: "الهاتف",
    content: "+966 50 123 4567",
  },
  {
    icon: Mail,
    title: "البريد الإلكتروني",
    content: "info@lamsat-onotha.com",
  },
  {
    icon: Clock,
    title: "ساعات العمل",
    content: "السبت - الخميس: 9 ص - 10 م",
  },
]

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    message: "",
  })

  const whatsappNumber = "966501234567"

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const message = encodeURIComponent(
      `مرحباً، أنا ${formData.name}\nرقم الهاتف: ${formData.phone}\n\n${formData.message}`
    )
    window.open(`https://wa.me/${whatsappNumber}?text=${message}`, "_blank")
  }

  return (
    <section id="contact" className="py-16 md:py-24 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">تواصلي معنا</h2>
          <p className="mt-4 text-muted-foreground text-lg">نسعد بخدمتك والرد على استفساراتك</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12 max-w-5xl mx-auto">
          {/* Contact Info */}
          <div className="space-y-4">
            {contactInfo.map((item, index) => (
              <Card key={index} className="bg-card">
                <CardContent className="p-5 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <item.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground">{item.title}</h3>
                    <p className="text-muted-foreground">{item.content}</p>
                  </div>
                </CardContent>
              </Card>
            ))}

            <Button
              className="w-full mt-4 gap-2 bg-green-500 hover:bg-green-600 text-white py-6 text-lg"
              asChild
            >
              <a
                href={`https://wa.me/${whatsappNumber}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <MessageCircle className="h-5 w-5" />
                <span>تواصلي عبر واتساب</span>
              </a>
            </Button>
          </div>

          {/* Contact Form */}
          <Card className="bg-card">
            <CardContent className="p-6 md:p-8">
              <h3 className="text-xl font-bold text-foreground mb-6">أرسلي رسالة</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Input
                    placeholder="الاسم"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="h-12"
                  />
                </div>
                <div>
                  <Input
                    type="tel"
                    placeholder="رقم الهاتف"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                    className="h-12"
                  />
                </div>
                <div>
                  <Textarea
                    placeholder="رسالتك"
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    required
                    className="min-h-32 resize-none"
                  />
                </div>
                <Button type="submit" className="w-full gap-2 py-6 text-lg">
                  <Send className="h-5 w-5" />
                  <span>إرسال الرسالة</span>
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
