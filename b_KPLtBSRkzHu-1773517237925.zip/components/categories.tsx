"use client"

import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"

const categories = [
  {
    id: "rings",
    name: "خواتم",
    nameEn: "Rings",
    image: "/images/category-rings.jpg",
    count: 24,
  },
  {
    id: "necklaces",
    name: "قلائد",
    nameEn: "Necklaces",
    image: "/images/category-necklaces.jpg",
    count: 18,
  },
  {
    id: "bracelets",
    name: "أساور",
    nameEn: "Bracelets",
    image: "/images/category-bracelets.jpg",
    count: 15,
  },
  {
    id: "earrings",
    name: "أقراط",
    nameEn: "Earrings",
    image: "/images/category-earrings.jpg",
    count: 21,
  },
]

interface CategoriesProps {
  onCategorySelect: (category: string | null) => void
  selectedCategory: string | null
}

export function Categories({ onCategorySelect, selectedCategory }: CategoriesProps) {
  return (
    <section id="categories" className="py-16 md:py-24 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">تصنيفاتنا</h2>
          <p className="mt-4 text-muted-foreground text-lg">اختاري التصنيف المناسب لذوقك</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {categories.map((category) => (
            <Card
              key={category.id}
              className={`group cursor-pointer overflow-hidden transition-all duration-300 hover:shadow-lg ${
                selectedCategory === category.id ? "ring-2 ring-primary" : ""
              }`}
              onClick={() => onCategorySelect(selectedCategory === category.id ? null : category.id)}
            >
              <CardContent className="p-0">
                <div className="relative aspect-square overflow-hidden">
                  <Image
                    src={category.image}
                    alt={category.name}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 to-transparent" />
                  <div className="absolute bottom-0 right-0 left-0 p-4 text-right">
                    <h3 className="text-xl md:text-2xl font-bold text-white">{category.name}</h3>
                    <p className="text-white/90 text-xs uppercase tracking-wide mb-1">{category.nameEn}</p>
                    <p className="text-white/80 text-sm">{category.count} منتج</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
