import { Instagram, Twitter } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-foreground text-background py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Brand */}
          <div>
            <h3 className="text-2xl font-bold text-primary-foreground">لمسة أنوثة</h3>
            <p className="mt-4 text-background/70 leading-relaxed">
              متجرك المفضل للإكسسوارات النسائية الراقية. نقدم لك أجمل التصاميم بأفضل الأسعار.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold text-primary-foreground mb-4">روابط سريعة</h4>
            <ul className="space-y-2">
              <li>
                <a href="#home" className="text-background/70 hover:text-primary-foreground transition-colors">
                  الرئيسية
                </a>
              </li>
              <li>
                <a href="#products" className="text-background/70 hover:text-primary-foreground transition-colors">
                  المنتجات
                </a>
              </li>
              <li>
                <a href="#categories" className="text-background/70 hover:text-primary-foreground transition-colors">
                  التصنيفات
                </a>
              </li>
              <li>
                <a href="#contact" className="text-background/70 hover:text-primary-foreground transition-colors">
                  تواصل معنا
                </a>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4 className="text-lg font-bold text-primary-foreground mb-4">تابعينا</h4>
            <div className="flex gap-4">
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-background/10 flex items-center justify-center hover:bg-primary transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-background/10 flex items-center justify-center hover:bg-primary transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-background/20 mt-10 pt-8 text-center">
          <p className="text-background/60">
            جميع الحقوق محفوظة &copy; {new Date().getFullYear()} لمسة أنوثة
          </p>
        </div>
      </div>
    </footer>
  )
}
