"use client"

import Image from "next/image"
import { MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export interface Product {
  id: string
  name: string
  description: string
  image: string
  category: string
}

interface ProductCardProps {
  product: Product
}

const WHATSAPP_NUMBERS = ["249996747084", "249129975822"]
const WHATSAPP_MESSAGE = "مرحبا، أريد الاستفسار عن هذا المنتج"

export function ProductCard({ product }: ProductCardProps) {
  const handleWhatsAppInquiry = (phoneNumber: string) => {
    const message = encodeURIComponent(`${WHATSAPP_MESSAGE}\n\nالمنتج: ${product.name}`)
    window.open(`https://wa.me/${phoneNumber}?text=${message}`, "_blank")
  }

  return (
    <Card className="group overflow-hidden transition-all duration-300 hover:shadow-xl bg-card">
      <CardContent className="p-0">
        <div className="relative aspect-square overflow-hidden">
          <Image
            src={product.image}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </div>

        <div className="p-4 md:p-5">
          <h3 className="text-lg md:text-xl font-bold text-foreground">{product.name}</h3>
          <p className="mt-2 text-muted-foreground text-sm line-clamp-2">{product.description}</p>

          <div className="mt-4 flex flex-col gap-2">
            <Button
              onClick={() => handleWhatsAppInquiry(WHATSAPP_NUMBERS[0])}
              className="w-full bg-[#25D366] hover:bg-[#128C7E] text-white"
            >
              <MessageCircle className="w-4 h-4 ml-2" />
              استفسار واتساب 1
            </Button>
            <Button
              onClick={() => handleWhatsAppInquiry(WHATSAPP_NUMBERS[1])}
              variant="outline"
              className="w-full border-[#25D366] text-[#25D366] hover:bg-[#25D366] hover:text-white"
            >
              <MessageCircle className="w-4 h-4 ml-2" />
              استفسار واتساب 2
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
