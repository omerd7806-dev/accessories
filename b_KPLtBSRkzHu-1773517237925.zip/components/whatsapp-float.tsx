"use client"

import { MessageCircle, X } from "lucide-react"
import { useState } from "react"

const WHATSAPP_NUMBERS = [
  { number: "249996747084", label: "واتساب 1" },
  { number: "249129975822", label: "واتساب 2" },
]
const WHATSAPP_MESSAGE = "مرحبا، أريد الاستفسار عن هذا المنتج"

export function WhatsAppFloat() {
  const [isOpen, setIsOpen] = useState(false)

  const handleWhatsAppClick = (phoneNumber: string) => {
    const message = encodeURIComponent(WHATSAPP_MESSAGE)
    window.open(`https://wa.me/${phoneNumber}?text=${message}`, "_blank")
    setIsOpen(false)
  }

  return (
    <div className="fixed bottom-6 left-6 z-50">
      {isOpen && (
        <div className="absolute bottom-16 left-0 bg-card rounded-xl shadow-xl border border-border p-4 mb-2 min-w-[200px] animate-in slide-in-from-bottom-2">
          <p className="text-sm text-muted-foreground mb-3 text-center">تواصل معنا عبر واتساب</p>
          <div className="flex flex-col gap-2">
            {WHATSAPP_NUMBERS.map((item, index) => (
              <button
                key={index}
                onClick={() => handleWhatsAppClick(item.number)}
                className="flex items-center gap-2 px-4 py-2 bg-[#25D366] hover:bg-[#128C7E] text-white rounded-lg transition-colors text-sm"
              >
                <MessageCircle className="w-4 h-4" />
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 bg-[#25D366] hover:bg-[#128C7E] text-white rounded-full shadow-lg flex items-center justify-center transition-all duration-300 hover:scale-110"
        aria-label="تواصل عبر واتساب"
      >
        {isOpen ? (
          <X className="w-6 h-6" />
        ) : (
          <MessageCircle className="w-6 h-6" />
        )}
      </button>
    </div>
  )
}
