"use client"

import { useState, useEffect } from "react"
import { ProductCard, Product } from "@/components/product-card"

const defaultProducts: Product[] = [
  {
    id: "1",
    name: "خاتم الماس ذهبي",
    description: "خاتم أنيق من الذهب الخالص مرصع بالألماس الطبيعي",
    image: "/images/ring-1.jpg",
    category: "rings",
  },
  {
    id: "2",
    name: "خاتم فضي كلاسيكي",
    description: "خاتم فضي بتصميم كلاسيكي مع حجر كريم",
    image: "/images/ring-2.jpg",
    category: "rings",
  },
  {
    id: "3",
    name: "قلادة لؤلؤ طبيعي",
    description: "قلادة من الذهب الوردي مع لؤلؤة طبيعية",
    image: "/images/necklace-1.jpg",
    category: "necklaces",
  },
  {
    id: "4",
    name: "قلادة كريستال ذهبية",
    description: "سلسلة ذهبية مع تعليقة كريستال لامعة",
    image: "/images/necklace-2.jpg",
    category: "necklaces",
  },
  {
    id: "5",
    name: "سوار سحر ذهبي",
    description: "سوار ذهبي مع تعليقات متنوعة أنيقة",
    image: "/images/bracelet-1.jpg",
    category: "bracelets",
  },
  {
    id: "6",
    name: "سوار لؤلؤ أنيق",
    description: "سوار من اللؤلؤ الطبيعي بتصميم راقي",
    image: "/images/bracelet-2.jpg",
    category: "bracelets",
  },
  {
    id: "7",
    name: "أقراط لؤلؤ متدلية",
    description: "أقراط متدلية من اللؤلؤ الأبيض الفاخر",
    image: "/images/earrings-1.jpg",
    category: "earrings",
  },
  {
    id: "8",
    name: "حلق ذهبي دائري",
    description: "حلق دائري من الذهب مع كريستالات صغيرة",
    image: "/images/earrings-2.jpg",
    category: "earrings",
  },
]

interface ProductGalleryProps {
  selectedCategory: string | null
}

export function ProductGallery({ selectedCategory }: ProductGalleryProps) {
  const [products, setProducts] = useState<Product[]>(defaultProducts)

  useEffect(() => {
    const savedProducts = localStorage.getItem("shop-products")
    if (savedProducts) {
      try {
        const parsed = JSON.parse(savedProducts)
        if (Array.isArray(parsed) && parsed.length > 0) {
          setProducts(parsed)
        }
      } catch (e) {
        console.error("Error loading products:", e)
      }
    }
  }, [])

  const filteredProducts = selectedCategory
    ? products.filter((p) => p.category === selectedCategory)
    : products

  const categoryNames: Record<string, string> = {
    rings: "الخواتم",
    necklaces: "القلائد",
    bracelets: "الأساور",
    earrings: "الأقراط",
  }

  return (
    <section id="products" className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            {selectedCategory ? categoryNames[selectedCategory] : "منتجاتنا المميزة"}
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">
            {selectedCategory
              ? `تصفحي مجموعتنا من ${categoryNames[selectedCategory]}`
              : "اكتشفي أحدث تشكيلاتنا من الإكسسوارات"}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">لا توجد منتجات في هذا التصنيف حالياً</p>
          </div>
        )}
      </div>
    </section>
  )
}
