import Image from "next/image"
import { Button } from "@/components/ui/button"

export function HeroBanner() {
  return (
    <section id="home" className="relative overflow-hidden">
      <div className="absolute inset-0">
        <Image
          src="/images/hero-banner.jpg"
          alt="مجموعة إكسسوارات نسائية"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-l from-background/95 via-background/70 to-transparent" />
      </div>
      
      <div className="container mx-auto px-4 relative">
        <div className="min-h-[500px] md:min-h-[600px] flex items-center">
          <div className="max-w-xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight text-balance">
              أناقتك تبدأ من هنا
            </h1>
            <p className="mt-6 text-lg md:text-xl text-muted-foreground leading-relaxed">
              اكتشفي أجمل تشكيلة من الإكسسوارات النسائية الراقية. خواتم، قلائد، أساور وأقراط بتصاميم عصرية وأسعار مناسبة.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Button size="lg" className="text-lg px-8" asChild>
                <a href="#products">تسوقي الآن</a>
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8" asChild>
                <a href="#categories">تصفحي التصنيفات</a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
